# App icon pack

Title: 「プリン」は絶対食べるなよ！

## iOS / iPadOS
All files are full square and opaque. No rounded corners are baked in.
Included pixel sizes: 20, 29, 40, 58, 60, 76, 80, 87, 120, 152, 167, 180, 1024.
For modern Xcode, icon_master_1024.png or ios/icon_1024x1024.png can be used as the master asset.

## Android
- play_store/icon_512x512.png
- legacy/mipmap-*/ic_launcher.png: 48, 72, 96, 144, 192 px
- adaptive/mipmap-*/ foreground/background layers: 108, 162, 216, 324, 432 px

The adaptive foreground is reduced to the centered 72/108 safe area.
